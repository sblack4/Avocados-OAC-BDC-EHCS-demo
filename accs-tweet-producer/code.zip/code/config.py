import logging 

consumer_key = ""
consumer_secret = ""
access_token = ""
access_secret = ""
track_string = ""

topic = ""
kafka_host = ""
log_level = logging.DEBUG