pip install -r requirements.txt -t modules
python kafka_broker.py